package com.example.ezy_food;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class QuantityActivity extends AppCompatActivity {

    Button inc, dec;
    TextView qty;
    int count;

    Button inc1, dec1;
    TextView qty1;
    int count1;

    Button inc2, dec2;
    TextView qty2;
    int count2;

    Button inc3, dec3;
    TextView qty3;
    int count3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.quantity);

        Button btn_more = findViewById(R.id.btn_more);
        Button btn_order = findViewById(R.id.btn_order);

        btn_order.setOnClickListener(view -> {
            Intent intent = new Intent(QuantityActivity.this, OrderActivity.class);
            startActivity(intent);
        });

        btn_more.setOnClickListener(view -> {
            Intent intent = new Intent(QuantityActivity.this, DrinksActivity.class);
            startActivity(intent);
        });

        inc = findViewById(R.id.inc);
        dec = findViewById(R.id.dec);
        qty = findViewById(R.id.qty);

        inc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                count++;
                qty.setText(count + "");
            }
        });
        dec.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (count == 0){
                    count+=1;
                }
                count--;
                qty.setText(count + "");
            }
        });

        inc1 = findViewById(R.id.inc1);
        dec1 = findViewById(R.id.dec1);
        qty1 = findViewById(R.id.qty1);

        inc1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                count1++;
                qty1.setText(count1 + "");
            }
        });
        dec1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (count1 == 0){
                    count1+=1;
                }
                count1--;
                qty1.setText(count1 + "");
            }
        });

        inc2 = findViewById(R.id.inc2);
        dec2 = findViewById(R.id.dec2);
        qty2 = findViewById(R.id.qty2);

        inc2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                count2++;
                qty2.setText(count2 + "");
            }
        });
        dec2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (count2 == 0){
                    count2+=1;
                }
                count2--;
                qty2.setText(count2 + "");
            }
        });

        inc3 = findViewById(R.id.inc3);
        dec3 = findViewById(R.id.dec3);
        qty3 = findViewById(R.id.qty3);

        inc3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                count3++;
                qty3.setText(count3 + "");
            }
        });
        dec3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (count3 == 0){
                    count3+=1;
                }
                count3--;
                qty3.setText(count3 + "");
            }
        });



    }
}
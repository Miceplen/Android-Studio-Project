package com.example.ezy_food;

public class MyOrder {
    String OrderName;
    String price;
    int thumbnail;
    String quantity;
}

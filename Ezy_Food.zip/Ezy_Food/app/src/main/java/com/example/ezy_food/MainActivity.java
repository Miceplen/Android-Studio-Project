package com.example.ezy_food;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;


public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ImageView btn_1 = findViewById(R.id.btn_1);

        btn_1.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, DrinksActivity.class);
            startActivity(intent);
        });

        Button btn_5 = findViewById(R.id.btn_5);

        btn_5.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, OrderActivity.class);
            startActivity(intent);
        });

    }
}
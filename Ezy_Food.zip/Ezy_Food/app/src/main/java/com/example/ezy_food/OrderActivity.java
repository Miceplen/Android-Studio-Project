package com.example.ezy_food;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import java.util.ArrayList;

public class OrderActivity extends AppCompatActivity {

    ArrayList<MyOrder> listOrder;
    RecyclerView rvOrder;
    OrderAdapter adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.my_order);

        listOrder = new ArrayList<>();

        MyOrder order_1 = new MyOrder();
        order_1.OrderName = "Air Mineral";
        order_1.price = "123";
        order_1.quantity = "1";
        order_1.thumbnail = R.drawable.mineral;

        MyOrder order_2 = new MyOrder();
        order_2.OrderName = "Jus Apel";
        order_2.price = "123";
        order_2.quantity = "2";
        order_2.thumbnail = R.drawable.apple;

        MyOrder order_3 = new MyOrder();
        order_3.OrderName = "Jus Mangga";
        order_3.price = "123";
        order_3.quantity = "3";
        order_3.thumbnail = R.drawable.mango;

        MyOrder order_4 = new MyOrder();
        order_4.OrderName = "Jus Alpukat";
        order_4.price = "123";
        order_4.quantity = "4";
        order_4.thumbnail = R.drawable.avocado;

        listOrder.add(order_1);
        listOrder.add(order_2);
        listOrder.add(order_3);
        listOrder.add(order_4);

        rvOrder = findViewById(R.id.rvOrder);
        rvOrder.setLayoutManager(new LinearLayoutManager(this));

        adapter = new OrderAdapter(this,listOrder);
        rvOrder.setAdapter(adapter);


        Button btn_pay = findViewById(R.id.btn_pay);

        btn_pay.setOnClickListener(view -> {
            Intent intent = new Intent(OrderActivity.this, PaymentActivity.class);
            startActivity(intent);
        });

    }
}
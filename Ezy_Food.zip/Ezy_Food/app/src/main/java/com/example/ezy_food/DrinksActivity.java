package com.example.ezy_food;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class DrinksActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.drinks);

        ImageView img_drink1 = findViewById(R.id.img_drink1);

        img_drink1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(DrinksActivity.this, QuantityActivity.class);
                startActivity(intent);
            }
        });

        ImageView img_drink2 = findViewById(R.id.img_drink2);

        img_drink2.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                Intent intent = new Intent(DrinksActivity.this, QuantityActivity.class);
                startActivity(intent);
            }
        });

        ImageView img_drink3 = findViewById(R.id.img_drink3);

        img_drink3.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                Intent intent = new Intent(DrinksActivity.this, QuantityActivity.class);
                startActivity(intent);
            }
        });

        ImageView img_drink4 = findViewById(R.id.img_drink4);

        img_drink4.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                Intent intent = new Intent(DrinksActivity.this, QuantityActivity.class);
                startActivity(intent);
            }
        });

        Button btn_order = findViewById(R.id.btn_order);

        btn_order.setOnClickListener(view -> {
            Intent intent = new Intent(DrinksActivity.this, OrderActivity.class);
            startActivity(intent);
        });
    }
}